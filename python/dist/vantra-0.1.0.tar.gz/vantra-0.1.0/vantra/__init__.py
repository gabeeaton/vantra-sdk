import os
import time
import uuid
import threading
import functools
from contextlib import contextmanager
from typing import Optional, Any
from collections import deque

try:
    import httpx
    _HTTP_CLIENT = httpx.Client(timeout=5.0)
except ImportError:
    _HTTP_CLIENT = None

VANTRA_ENDPOINT = os.environ.get("VANTRA_ENDPOINT", "https://vantra.io/api/v1/ingest")

_config = {
    "api_key": None,
    "project": None,
    "enabled": True,
}

# Batch queue: flush every 500ms or every 50 events
_queue: deque = deque()
_queue_lock = threading.Lock()
_flush_interval = 0.5

def _flush_worker():
    while True:
        time.sleep(_flush_interval)
        _flush()

def _flush():
    with _queue_lock:
        if not _queue:
            return
        items = list(_queue)
        _queue.clear()

    traces = [i for i in items if i["_type"] == "trace"]
    spans = [i for i in items if i["_type"] == "span"]

    for item in items:
        del item["_type"]

    if traces:
        _post("/traces", traces if len(traces) > 1 else traces[0])
    if spans:
        _post("/spans", spans)

def _post(path: str, data):
    if not _config["api_key"] or not _HTTP_CLIENT:
        return
    try:
        _HTTP_CLIENT.post(
            f"{VANTRA_ENDPOINT}{path}",
            json=data,
            headers={"Authorization": f"Bearer {_config['api_key']}"},
        )
    except Exception:
        pass


def init(api_key: str, project: str, enabled: bool = True, patch_openai: bool = True, patch_anthropic: bool = True):
    _config["api_key"] = api_key
    _config["project"] = project
    _config["enabled"] = enabled

    # Start background flush thread
    t = threading.Thread(target=_flush_worker, daemon=True)
    t.start()

    if patch_openai:
        from vantra.integrations.openai import patch
        patch()

    if patch_anthropic:
        from vantra.integrations.anthropic import patch
        patch()


def trace(func=None, *, name: str = None):
    """Decorator to wrap an entire function as a root trace."""
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            if not _config["enabled"]:
                return fn(*args, **kwargs)

            trace_id = str(uuid.uuid4())
            trace_name = name or fn.__name__
            start = time.time()
            status = "ok"
            error_msg = None

            try:
                result = fn(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                error_msg = str(e)
                raise
            finally:
                end = time.time()
                with _queue_lock:
                    _queue.append({
                        "_type": "trace",
                        "trace_id": trace_id,
                        "name": trace_name,
                        "project": _config["project"],
                        "start_time": start,
                        "end_time": end,
                        "duration_ms": int((end - start) * 1000),
                        "status": status,
                        "error_message": error_msg,
                    })

        return wrapper

    if func is not None:
        return decorator(func)
    return decorator


@contextmanager
def span(name: str, kind: str = "chain", model: str = None, trace_id: str = None, **metadata):
    """Context manager for a single span within a trace."""
    span_id = str(uuid.uuid4())
    start = time.time()
    status = "ok"
    error_msg = None
    _output = {}
    _tokens = {}

    class SpanContext:
        id = span_id

        def set_output(self, data: Any):
            _output["output"] = _truncate(data)

        def set_tokens(self, input_tokens: int, output_tokens: int):
            _tokens["input_tokens"] = input_tokens
            _tokens["output_tokens"] = output_tokens

    ctx = SpanContext()
    try:
        yield ctx
    except Exception as e:
        status = "error"
        error_msg = str(e)
        raise
    finally:
        end = time.time()
        with _queue_lock:
            _queue.append({
                "_type": "span",
                "span_id": span_id,
                "trace_id": trace_id,
                "name": name,
                "kind": kind,
                "model": model,
                "project": _config["project"],
                "start_time": start,
                "end_time": end,
                "duration_ms": int((end - start) * 1000),
                "status": status,
                "error_message": error_msg,
                "metadata": metadata,
                **_output,
                **_tokens,
            })


def _truncate(data: Any, max_chars: int = 2000) -> Any:
    import json
    try:
        s = json.dumps(data)
        if len(s) <= max_chars:
            return data
        return {"_truncated": True, "preview": s[:max_chars]}
    except Exception:
        return str(data)[:max_chars]
